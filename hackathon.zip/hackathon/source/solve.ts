import { Question } from "./question";
import { User } from "./user";

export interface SolveStrategy {
    solve(question: Question, user:User, time:number): void;
}

export class SimpleSolve implements SolveStrategy {
    solve(question: Question, user:User, time:number): void {
        console.log(`Solving question ${question.id} by ${user.userID} in ${time} seconds`);

        question.solvedBy.push({
            questionId: question.id,
            userId: user.userID,
            time
        });

        user.solvedProblems.push({
            questionId: question.id,
            time
        });

        user.score += question.score;

        let [totalTime, totalCount] = [0, 0]
        for(let time of question.solvedBy) {
            totalTime += time.time;
            totalCount+=1;
        }
        question.avgTime = totalTime/totalCount;
    }
}