/**
 * 
 * Hackthon -> 
 * Question library
 * Register -> name, department name
 * Problem -> desc , tag, difficulty level, score
 * Filter problem -> 
 * Solve -> 
 * AvgTime
 * Stratey ->
 * displayLeaderboard -> top n contestants and top n departments
 * 
 * 
 * Extension
 * On solving user should get top 5
 * top 10 -> solved problem
 * 
 * 
 * 
 */

/***
 * 
 * 
 * 
 * UserScore: score
 * User : name, department
 * Question : Desc, Tag, Difficulty, Score, AvgTime
 * QuestionPool
 * SolveStrategy
 * Solve
 * sugestionStrategy
 * suggestion
 * LeaderBoard: getTopNContestants, getTopNDepartments
 * Hackthon: addUser, fetchProblems, solve, fetchSolvedProblems, displayLeaderboard
 * 
 * 
 * 
 * 
 * User ->
 */



import { Hackathon } from "./hackathon";



const admin = Hackathon.getAdminService();

admin.addQuestion('Question 1', 'easy', 10);
admin.addQuestion('Question 2', 'medium', 20);
admin.addQuestion('Question 3', 'hard', 30);
admin.addQuestion('Question 4', 'easy', 15);
admin.addQuestion('Question 5', 'medium', 25);
admin.addQuestion('Question 6', 'hard', 35);

const userService = Hackathon.getUserService();

const user1 = userService.createUser('User 1', 'Department 1');
const user2 = userService.createUser('User 2', 'Department 2');
const user3 = userService.createUser('User 3', 'Department 1');
const user4 = userService.createUser('User 4', 'Department 2');


console.log('Fetch Easy Problems')
console.log(userService.fetchProblems(user1, { difficulty: 'easy' }));

console.log('Fetch All Problems')
console.log(userService.fetchProblems(user1, { }));

userService.solve(user1, 1, 10);

console.log('Fetch Easy Problems After User 1 Solved 1st Problem');
console.log(userService.fetchProblems(user1, { difficulty: 'easy' }));


console.log('Fetch Solved Problems of User 1');
console.log(userService.fetchSolvedProblems(user1));


userService.solve(user2, 1, 20);
console.log(userService.fetchProblems(user1, { difficulty: 'easy' }));

userService.solve(user3, 2, 30);

console.log('Fetch Solved Problems of User 1 Again, just to check if Average time got updated');
console.log(userService.fetchSolvedProblems(user1));

console.log('Get Top 10 Contestants');
console.log(userService.getTopNContestants(10));

console.log('Get Top 10 Departmernts');
console.log(userService.getTopNDepartments(10));



