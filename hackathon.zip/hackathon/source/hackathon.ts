import { QuestionPool } from "./questionPool";
import { AdminService, UserService } from "./services";

export class Hackathon {
    
    private static instance: Hackathon;
    private constructor(private adminService: AdminService,private userService: UserService){}

    private static getInstance(): Hackathon {
        if (!this.instance) {
            const questionPool = new QuestionPool();
            this.instance = new Hackathon(new AdminService(questionPool), new UserService(questionPool));
        }
        return this.instance;
    }

    static getUserService(): UserService {
        return this.getInstance().userService;
    }

    static getAdminService(): AdminService {
        return this.getInstance().adminService;
    }

}