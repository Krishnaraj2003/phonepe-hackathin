interface QuestionInterface {
    id:number;
    desc:string;
    difficulty:'easy'|'medium'|'hard';
    score:number;
    avgTime:number;
    solvedBy: QuestionSolvedInterface[]; //Implement a hash table if possible

}


interface QuestionSolvedInterface {
    questionId:number;
    userId:number;
    time:number;
}

export class Question implements QuestionInterface {
    constructor(public id:number, public desc: string, public difficulty: 'easy'|'medium'|'hard', public score: number, public avgTime: number, public solvedBy: QuestionSolvedInterface[]) {}
}

export class QuestionFactory {
    private static questionCount = 0;
    static createQuestion(desc: string, difficulty: 'easy'|'medium'|'hard', score:number): Question {
        this.questionCount++;
        return new Question(this.questionCount, desc, difficulty, score, 0, []);
    }
}


