import { Question, QuestionFactory } from "./question";

interface QuestionPoolInterface {
    questions: {[id:number]:Question};
    addQuestion(desc: string, difficulty: 'easy' | 'medium' | 'hard', score: number): Question;
    getQuestion(questionID: number): Question;
}

export class QuestionPool implements QuestionPoolInterface {
    public questions: {[id:number]:Question} = {};
    addQuestion(desc: string, difficulty: 'easy' | 'medium' | 'hard', score: number): Question {
        const question = QuestionFactory.createQuestion(desc, difficulty, score);
        this.questions[question.id] = question;
        return question;
    }
    getQuestion(questionID: number): Question {
        if(!this.questions[questionID]){
            throw new Error('Question not found');
        }
        return this.questions[questionID];
    }
    
}