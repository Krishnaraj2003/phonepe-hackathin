import { User, UserFactory } from "./user";

interface UserPoolInterface {
    addUser(name: string, department: string): User;
    getUser(userID: number): User;
}

export class UserPool implements UserPoolInterface {
    private users: { [id: number]: User; } = {};


    addUser(name: string, department: string): User {
        const user = UserFactory.createUser(name, department);
        this.users[user.userID] = user;
        return user;
    }
    getUser(userID: number): User {
        if (!this.users[userID]) {
            throw new Error('User not found');
        }
        return this.users[userID];
    }

    getTopNUsers(n: number): User[] {
        const users = Object.values(this.users);
        return users.sort((a, b) => b.score - a.score).slice(0, n);
    }
}