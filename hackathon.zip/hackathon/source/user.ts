interface UserInterface {
    userID: number;
    name: string;
    department: string;
    score: number;
    solvedProblems: UserSolvedProblemsInterface[]; 
}

interface UserSolvedProblemsInterface {
    questionId:number;
    time:number;
}


export class User implements UserInterface {
    constructor(public userID:number, public name: string, public department: string, public score: number, public solvedProblems:UserSolvedProblemsInterface[]) {}
}


/**
 * 
 * Need to add observers that will create department at leaderBoard 
 */
export class UserFactory {
    private static userCount = 0;
    static createUser(name: string, department: string): User {
        this.userCount++;
        return new User(this.userCount, name, department, 0, []);
    }
}