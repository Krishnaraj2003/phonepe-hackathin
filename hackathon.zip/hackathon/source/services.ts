import { DepartmentCount } from "./departmentCount";
import { Question } from "./question";
import { QuestionPool } from "./questionPool";
import { SimpleSolve, SolveStrategy } from "./solve";
import { User } from "./user";
import { UserPool } from "./userPool";

interface UserServiceInterface {
    createUser(name: string, department: string): number;
    solve(userID: number, questionID: number, time: number): void;
    fetchProblems(userID: number, filter: FilterInterface): Question[];
    fetchSolvedProblems(userID: number): Question[];

}

interface AdminServiceInterface {
    addQuestion(desc: string, difficulty: 'easy' | 'medium' | 'hard', score: number): number;

}

interface FilterInterface {
    difficulty?: 'easy' | 'medium' | 'hard';
    score?: number;
}


export class UserService implements UserServiceInterface {
    private userPool: UserPool;
    private solveStrategy: SolveStrategy;
    private department: DepartmentCount;

    constructor(private questionPool: QuestionPool) {
         this.userPool = new UserPool();
         this.solveStrategy = new SimpleSolve();
         this.department = new DepartmentCount();
     }
    createUser(name: string, department: string): number {
        const user = this.userPool.addUser(name, department);
        this.department.addDepartment(user.department);
        return user.userID;
    }
    
    solve(userID: number, questionID: number, time: number): void {
        const user = this.userPool.getUser(userID);
        const question = this.questionPool.getQuestion(questionID);

        //Solve
        this.solveStrategy.solve(question, user, time);

        this.department.updateCount(user.department, question.score);
    }
    
    fetchProblems(userID: number, filter: FilterInterface): Question[] {
        const resultArr = [];
        const user = this.userPool.getUser(userID);
        for (const question of Object.values(this.questionPool.questions)) {
            if(filter.difficulty && question.difficulty !== filter.difficulty){
                continue;
            }
            if(filter.score && question.score !== filter.score){
                continue;
            }
            if(user.solvedProblems.find((problem) => problem.questionId === question.id)){
                continue;
            }
            resultArr.push(question);
        }
        return resultArr;
    }

    fetchSolvedProblems(userID: number): Question[] {
        const resultArr = [];
        const user = this.userPool.getUser(userID);
        for(let solved of user.solvedProblems){
            resultArr.push(this.questionPool.getQuestion(solved.questionId));
        }
        return resultArr;
    }

    getTopNContestants(n: number): User[] {
        return this.userPool.getTopNUsers(n);
    }

    getTopNDepartments(n: number): [string, number][] {
        return this.department.getTopDepartment(n);
    }
}

export class AdminService implements AdminServiceInterface {

    constructor(private questionPool: QuestionPool) {}

    addQuestion(desc: string, difficulty: 'easy' | 'medium' | 'hard', score: number): number {
        const data = this.questionPool.addQuestion(desc, difficulty, score);
        return data.id;
    }

}